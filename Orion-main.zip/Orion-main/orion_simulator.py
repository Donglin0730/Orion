import random
from dataclasses import dataclass
from typing import List, Tuple, Dict,Callable, Optional, Sequence,Union
import numpy as np
import pandas as pd
from itertools import combinations
import time
random.seed(0)
np.random.seed(0) # Reproducibility.
MAX_SUBSEQ_PER_DEVICE_FACTOR=4
MIN_SUBSEQ_LEN = 16
@dataclass
class EdgeDevice:
    name: str
    perf: float
    mem_gb: float
    is_source: bool = False
@dataclass
class EdgeNetwork:
    bw_mbps: Dict[Tuple[str, str], float]  # symmetric bandwidth in Mbps
    def mbps(self, u: str, v: str) -> float:
        if (u, v) in self.bw_mbps: return self.bw_mbps[(u, v)]
        if (v, u) in self.bw_mbps: return self.bw_mbps[(v, u)]
        return 1.0

@dataclass
class LLMProfile:
    name: str
    n_layers: int
    mem_gb_required: float
    act_mb_per_layer: List[float]
    base_compute_ms_per_layer: List[float]
    mem_gb_required_per_layer: List[float]

def build_uav_swarm_devices() -> List[EdgeDevice]:
    return [
        EdgeDevice("AGX_Orin1", perf=1.0,  mem_gb=16.0),
        EdgeDevice("AGX_Orin2", perf=1.0,  mem_gb=16.0),
        EdgeDevice("AGX_Orin3", perf=1.0,  mem_gb=16.0),
        EdgeDevice("Orin_NX",  perf=0.65, mem_gb=32.0, is_source=True),
        EdgeDevice("RTX3090",  perf=36.0,  mem_gb=32.0),
    ]

def build_fanet_network(devs: List[EdgeDevice]) -> EdgeNetwork:
    names = [d.name for d in devs]
    bw = {}
    for i in range(len(names)):
        for j in range(i+1, len(names)):
            u, v = names[i], names[j]
            if (("Orin_NX" in (u, v)) or ("AGX_Orin1" in (u, v)) or ("AGX_Orin2" in (u, v))or ("AGX_Orin3" in (u, v)) ) and ("RTX3090" in (u, v)):
                bw[(u, v)] =200  # UAV-cloud link
            else:
                base = 1000.0  # inter-device link
                jitter = base * 0.2 * (random.random()*2 - 1)
                bw[(u, v)] = max(5.0, base + jitter)
    return EdgeNetwork(bw_mbps=bw)

def build_llama_profile(name: str) -> LLMProfile:
    if name == "Llama2-7B":
        n, memall = 32, 28.0
    elif name == "Llama2-13B":
        n, memall= 40, 52.0
    elif name == "Llama2-70B":
        n, memall= 80, 70.0
    else:
        raise ValueError("unknown model")
    acts  = [8.0 + 0.05*i + random.random()*0.5 for i in range(n)]
    comps = [2.0 + 0.03*i + random.random()*0.2 for i in range(n)]
    mem= [memall / n  for _ in range(n)]
    return LLMProfile(name=name, n_layers=n, act_mb_per_layer=acts,
                    base_compute_ms_per_layer=comps, mem_gb_required_per_layer=mem,mem_gb_required=memall)

def transmission_latency_ms(net: EdgeNetwork, u: str, v: str, act_mb: float) -> float:
    mbps = max(0.1, net.mbps(u, v))
    return (act_mb * 8.0 * 1000.0) / mbps
def layer_compute_latency_ms(base_ms: float, perf: float) -> float:
    return base_ms / max(1e-6, perf)
def sequential_inference_latency_ms(model: LLMProfile, devices: List[EdgeDevice], net: EdgeNetwork,
                              shards: List[Tuple[int,int]], place: List[int], src_idx: int) -> float:
    ms = 0.0
    for si, (i0, i1) in enumerate(shards):
        dev = devices[place[si]]
        for L in range(i0, i1+1):
            ms += layer_compute_latency_ms(model.base_compute_ms_per_layer[L], dev.perf)
        if si > 0:
            prev = devices[place[si-1]]
            act_mb = model.act_mb_per_layer[i0-1]
            ms += transmission_latency_ms(net, prev.name, dev.name, act_mb)
    last = devices[place[-1]]
    if last.name != devices[src_idx].name:
        act_mb = model.act_mb_per_layer[shards[-1][1]]
        ms += transmission_latency_ms(net, last.name, devices[src_idx].name, act_mb)
    return ms
def edge_solo_baseline(model, devs, net,S_prefill:int):
    src_idx = next(i for i,d in enumerate(devs) if d.is_source)
    if model.mem_gb_required>devs[src_idx].mem_gb: return None,"OOM"
    ms = sequential_inference_latency_ms(model, devs, net, [(0,model.n_layers-1)], [src_idx], src_idx)
    return ms*S_prefill,"OK"
def even_layer_partition(n_layers, k):
    size, rem = n_layers//k, n_layers%k
    cur, out = 0, []
    for i in range(k):
        add = size + (1 if i<rem else 0)
        out.append((cur, cur+add-1))
        cur += add
    return out
def cloud_uav_even_baseline(model, devs, net,S_prefill:int):
    src_idx = next(i for i,d in enumerate(devs) if d.is_source)
    cloud_idx = next(i for i,d in enumerate(devs) if "RTX3090" in d.name)
    need_each = model.mem_gb_required/2
    if need_each>devs[src_idx].mem_gb or need_each>devs[cloud_idx].mem_gb:
        return None,"OOM"
    shards = even_layer_partition(model.n_layers,2)
    place = [src_idx, cloud_idx]
    ms = sequential_inference_latency_ms(model, devs, net, shards, place, src_idx)
    return ms*S_prefill,"OK"
def cloud_uav_optimal_cut_baseline(model, devs, net,S_prefill:int):
    src_idx = next(i for i,d in enumerate(devs) if d.is_source)
    cloud_idx = next(i for i,d in enumerate(devs) if "RTX3090" in d.name)
    best=(None,"OOM")
    for cut in range(1, model.n_layers):
        r_src = cut/model.n_layers; r_cld = 1.0-r_src
        need_src = model.mem_gb_required*r_src
        need_cld = model.mem_gb_required*r_cld
        if need_src>devs[src_idx].mem_gb or need_cld>devs[cloud_idx].mem_gb: continue
        shards=[(0,cut-1),(cut,model.n_layers-1)]
        place=[src_idx,cloud_idx]
        ms = sequential_inference_latency_ms(model, devs, net, shards, place, src_idx)
        if best[0] is None or ms*S_prefill < best[0]:
            best=(ms*S_prefill,"OK")
    return best

def optimal_llm_partition(model, devs, net):
    """
    Return R = [(start_layer, end_layer, device_index), ...].
    The cloud node is excluded from this edge-only partition.
    """
    def is_cloud(d: EdgeDevice) -> bool:
        return "RTX3090" in d.name  # cloud naming convention

    IDX = tuple(i for i, d in enumerate(devs) if not is_cloud(d))
    if not IDX:
        print("No available edge devices.")
        return []

    N = model.n_layers
    INF = float('inf')

    pref_mem = [0.0]
    for x in model.mem_gb_required_per_layer:
        pref_mem.append(pref_mem[-1] + float(x))

    def range_mem(a, b):
        return pref_mem[b+1] - pref_mem[a]

    pref_comp = {j: [0.0]*(N+1) for j in IDX}
    for j in IDX:
        acc = 0.0
        for l in range(N):
            acc += layer_compute_latency_ms(model.base_compute_ms_per_layer[l], devs[j].perf)
            pref_comp[j][l+1] = acc

    def range_comp_time(j, a, b):
        return pref_comp[j][b+1] - pref_comp[j][a]

    g = {}
    choice = {}

    for i in range(N):
        for subset_size in range(1, min(i+2, len(IDX))+1):
            for S in combinations(IDX, subset_size):
                S_frozen = frozenset(S)
                for k in S:
                    g[(i, S_frozen, k)] = INF
                    choice[(i, S_frozen, k)] = None

    for i in range(N):
        for j in IDX:
            if devs[j].mem_gb >= range_mem(0, i):
                g[(i, frozenset({j}), j)] = range_comp_time(j, 0, i)
                choice[(i, frozenset({j}), j)] = (-1, j, j)

    for i in range(N-1):
        max_subset = min(i+2, len(IDX))
        for subset_size in range(1, max_subset+1):
            for S in combinations(IDX, subset_size):
                S_frozen = frozenset(S)
                for k in S:
                    cur = g[(i, S_frozen, k)]
                    if cur == INF:
                        continue
                    for m in range(i+1, N):
                        remaining = set(IDX) - set(S)
                        for j in remaining:
                            if devs[j].mem_gb < range_mem(i+1, m):
                                continue
                            S_new = S_frozen | {j}
                            comp_time = range_comp_time(j, i+1, m)
                            act_mb = float(model.act_mb_per_layer[i])
                            
                            comm_time = transmission_latency_ms(net, devs[k].name, devs[j].name, act_mb)
                            T_max = max(cur, comp_time + comm_time)
                            key = (m, S_new, j)
                            if T_max < g.get(key, INF):
                                g[key] = T_max
                                choice[key] = (i, j, k)

    min_time = INF
    best_S, best_k = None, None
    for subset_size in range(1, len(IDX)+1):
        for S in combinations(IDX, subset_size):
            S_frozen = frozenset(S)
            for k in S:
                val = g.get((N-1, S_frozen, k), INF)
                if val < min_time:
                    min_time = val
                    best_S = S_frozen
                    best_k = k

    if best_S is None:
        print("No valid partition found: edge devices are insufficient or out of memory.")
        return []

    R = []
    layer = N - 1
    current_S = best_S
    current_k = best_k
    while layer > -1:
        prev_i, new_dev_j, prev_dev_k = choice[(layer, current_S, current_k)]
        R.append((prev_i + 1, layer, new_dev_j))
        layer = prev_i
        if current_S is not None and new_dev_j in current_S:
            current_S = current_S - {new_dev_j}
        current_k = prev_dev_k

    R.reverse()
    return R
from itertools import combinations

def cloud_assisted_llm_partition(model, devs, net):
    """
    R: [(start_layer, end_layer, device_index), ...]
    First and last stages must run on edge devices; intermediate stages may use the cloud.
    """
    
    N = model.n_layers
    ALL_IDX = tuple(range(len(devs)))
    local_indices = [i for i, d in enumerate(devs) if "RTX3090" not in d.name]
    
    if not local_indices:
        print("No local devices are available for the first and last stages.")
        return []

    INF = float('inf')

    pref_mem = [0.0]
    for x in model.mem_gb_required_per_layer:
        pref_mem.append(pref_mem[-1] + float(x))
    def range_mem(a, b): return pref_mem[b+1] - pref_mem[a]

    pref_comp = {j: [0.0]*(N+1) for j in ALL_IDX}
    for j in ALL_IDX:
        acc = 0.0
        for l in range(N):
            acc += layer_compute_latency_ms(model.base_compute_ms_per_layer[l], devs[j].perf)
            pref_comp[j][l+1] = acc
    def range_comp_time(j, a, b): return pref_comp[j][b+1] - pref_comp[j][a]

    g = {}      # (layer_idx, S_frozen, curr_dev_k)
    choice = {} # backpointers

    for i in range(N):
        for j in local_indices: 
            if devs[j].mem_gb >= range_mem(0, i):
                state = (i, frozenset({j}), j)
                g[state] = range_comp_time(j, 0, i)
                choice[state] = (-1, j, -1)

    for i in range(N - 1):
        
        current_layer_states = [key for key in g.keys() if key[0] == i]
        
        for state_key in current_layer_states:
            _, S_frozen, k = state_key
            cur_bottleneck = g[state_key]
            
            for m in range(i + 1, N):
                
                remaining_devs = set(ALL_IDX) - S_frozen
                for j in remaining_devs:
                    if devs[j].mem_gb < range_mem(i+1, m):
                        continue
                    
                    comp_time = range_comp_time(j, i+1, m)
                    act_mb = float(model.act_mb_per_layer[i])
                    comm_time = transmission_latency_ms(net, devs[k].name, devs[j].name, act_mb)
                    
                    T_max = max(cur_bottleneck, comp_time + comm_time)
                    new_state = (m, S_frozen | {j}, j)
                    
                    if T_max < g.get(new_state, INF):
                        g[new_state] = T_max
                        choice[new_state] = (i, j, k)

    min_time = INF
    best_final_key = None

    
    final_states = [key for key in g.keys() if key[0] == N - 1 and key[2] in local_indices]
    
    for key in final_states:
        if g[key] < min_time:
            min_time = g[key]
            best_final_key = key

    if not best_final_key:
        print("No partition satisfies the local first/last-stage constraint.")
        return []

    R = []
    curr_key = best_final_key
    while curr_key:
        layer_idx, S_frozen, k = curr_key
        prev_i, dev_j, prev_k = choice[curr_key]
        R.append((prev_i + 1, layer_idx, dev_j))
        if prev_i == -1: break
        prev_S = S_frozen - {dev_j}
        curr_key = (prev_i, prev_S, prev_k)

    R.reverse()
    return R

def build_stage_latency_model(
    device: EdgeDevice,
    layers_count: int,
    model: LLMProfile,
    *,
    calibrate: bool = False,
    sampler: Optional[Callable[[int, int], float]] = None,
    x_grid: Sequence[int] = (64, 96, 128, 192, 256, 384, 512),
    y_grid: Sequence[int] = (0, 1024, 2048, 4096, 6144, 8192),
) -> Tuple[Callable[[int, int], float], dict]:
    """
    Build q(x, y), the latency model for a stage handling x new tokens
    after y historical tokens.
      - info: {'a','b','c','d','layers_count','perf',...}
    """
    comps_mean = float(np.mean(model.base_compute_ms_per_layer))
    acts_mean  = float(np.mean(model.act_mb_per_layer))

    a = (layers_count * comps_mean) / max(device.perf, 1e-8)
    b = (0.12 * acts_mean * layers_count) / (max(device.perf, 1e-8) * 8192.0)
    c = (0.015 * a) / 512.0
    d = 1.0 if device.perf >= 2.0 else 2.0

    if calibrate:
        if sampler is None:
            raise ValueError("calibrate=True requires sampler(x, y)")
        X, y = [], []
        for yv in y_grid:
            for xv in x_grid:
                X.append([xv, xv*yv, xv*xv, 1.0])
                y.append(sampler(xv, yv))
        X = np.array(X, dtype=float)
        y = np.array(y, dtype=float)
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        coef = np.maximum(coef, 0.0)
        a,b,c,d = map(float, coef)

    def q(x:int, y:int) -> float:
        return a*x + b*x*y + c*(x**2) + d

    info = {"a":a, "b":b, "c":c, "d":d,
            "layers_count": layers_count,
            "perf": device.perf,
            }
    return q, info

def print_partition_plan(R, devs):
    total_layers = 0
    for (s, e, j) in R:
        print(f"layers [{s:>2d}..{e:>2d}] -> dev#{j} ({devs[j].name})")
        total_layers += (e - s + 1)
    print(f"segments = {len(R)}, total_layers = {total_layers}")

def stage_latency_ms(x: int, y_prev: int,devs,model,net,R_cache=None) -> float:
    if R_cache is None:
        R_cache = optimal_llm_partition(model, devs, net)
    s, e, j = R_cache[0]
    q, _=build_stage_latency_model(devs[j], e-s+1, model, calibrate=False)
    ms=q(x,y_prev)
    return ms

def adaptive_sequence_partition(S: int, max_subseq: int, min_len: int, devs, model, net):
    R = optimal_llm_partition(model, devs, net)
    N = max(1, len(R))  # guard against empty partitions

    qmat = np.zeros((S+1, S+1))
    for x in range(S+1):
        for y in range(S+1 - x):
            qmat[x, y] = float(stage_latency_ms(x, y, devs, model, net))

    W = np.full((S+1, max_subseq+1), np.inf)
    prev = [[-1]*(max_subseq+1) for _ in range(S+1)]
    W[0][0] = 0.0

    for y in range(1, S+1):
        for k in range(1, min(max_subseq, y)+1):
            best, best_l = np.inf, -1
            for l in range(0, y):
                seg_len = y - l
                if seg_len < min_len and not (y == S and seg_len > 0 and y < min_len):
                    continue
                if not np.isfinite(W[l][k-1]):
                    continue
                cand = max(float(W[l][k-1]), float(qmat[seg_len, l]))
                if cand < best:
                    best, best_l = cand, l
            if best_l != -1:
                W[y][k] = best
                prev[y][k] = best_l

    best_k = None
    best_total = np.inf

    for k_try in range(1, max_subseq+1):
        if not np.isfinite(W[S][k_try]):
            continue

        parts, y_cur, kk = [], S, k_try
        while kk > 0:
            l = prev[y_cur][kk]
            if l < 0:
                parts = [S]  # fallback to one segment
                break
            parts.append(y_cur - l)
            y_cur, kk = l, kk - 1
        parts.reverse()
        if not parts:
            continue

        yprev, h_list = 0, []
        for seg in parts:
            h_list.append(float(qmat[seg, yprev]))
            yprev += seg
        if not h_list:
            continue

        total_cost = float(np.sum(h_list)) + (N - 1) * float(np.max(h_list))

        if total_cost < best_total:
            best_total = total_cost
            best_k = k_try

    if best_k is None:
        return [S], float(qmat[S, 0])

    parts, y_cur, kk = [], S, best_k
    while kk > 0:
        l = prev[y_cur][kk]
        if l < 0:
            parts = [S]; break
        parts.append(y_cur - l)
        y_cur, kk = l, kk - 1
    parts.reverse()

    yprev, h_list = 0, []
    for seg in parts:
        h_list.append(float(qmat[seg, yprev]))
        yprev += seg
    return parts, (max(h_list) if h_list else 0.0)
def adaptive_sequence_partition_cloud_assisted(S: int, max_subseq: int, min_len: int, devs, model, net):
    R = cloud_assisted_llm_partition(model, devs, net)
    N = max(1, len(R))  # guard against empty partitions

    qmat = np.zeros((S+1, S+1))
    for x in range(S+1):
        for y in range(S+1 - x):
            qmat[x, y] = float(stage_latency_ms(x, y, devs, model, net))

    W = np.full((S+1, max_subseq+1), np.inf)
    prev = [[-1]*(max_subseq+1) for _ in range(S+1)]
    W[0][0] = 0.0

    for y in range(1, S+1):
        for k in range(1, min(max_subseq, y)+1):
            best, best_l = np.inf, -1
            for l in range(0, y):
                seg_len = y - l
                if seg_len < min_len and not (y == S and seg_len > 0 and y < min_len):
                    continue
                if not np.isfinite(W[l][k-1]):
                    continue
                cand = max(float(W[l][k-1]), float(qmat[seg_len, l]))
                if cand < best:
                    best, best_l = cand, l
            if best_l != -1:
                W[y][k] = best
                prev[y][k] = best_l

    best_k = None
    best_total = np.inf

    for k_try in range(1, max_subseq+1):
        if not np.isfinite(W[S][k_try]):
            continue

        parts, y_cur, kk = [], S, k_try
        while kk > 0:
            l = prev[y_cur][kk]
            if l < 0:
                parts = [S]  # fallback to one segment
                break
            parts.append(y_cur - l)
            y_cur, kk = l, kk - 1
        parts.reverse()
        if not parts:
            continue

        yprev, h_list = 0, []
        for seg in parts:
            h_list.append(float(qmat[seg, yprev]))
            yprev += seg
        if not h_list:
            continue

        total_cost = float(np.sum(h_list)) + (N - 1) * float(np.max(h_list))

        if total_cost < best_total:
            best_total = total_cost
            best_k = k_try

    if best_k is None:
        return [S], float(qmat[S, 0])

    parts, y_cur, kk = [], S, best_k
    while kk > 0:
        l = prev[y_cur][kk]
        if l < 0:
            parts = [S]; break
        parts.append(y_cur - l)
        y_cur, kk = l, kk - 1
    parts.reverse()

    yprev, h_list = 0, []
    for seg in parts:
        h_list.append(float(qmat[seg, yprev]))
        yprev += seg
    return parts, (max(h_list) if h_list else 0.0)
def orion_prefill_latency_ms(model,devs,S_prefill:int,net):
    R=optimal_llm_partition(model, devs, net)
    if not R:  # return a safe default for empty partitions
        return 0.0, {"error": "No valid partition found"}
    
    _,_,j=R[0]
    _,_,i=R[-1]
    N=len(R)
    max_subseq = MAX_SUBSEQ_PER_DEVICE_FACTOR * N
    parts_tokens, max_hi = adaptive_sequence_partition(S_prefill, max_subseq, MIN_SUBSEQ_LEN,devs,model,net)
    h_list, yprev = [], 0
    for seg in parts_tokens:
        h_list.append(stage_latency_ms(seg, yprev,devs,model,net))
        yprev += seg
    sum_hi = sum(h_list)
    
    last_layer_idx = min(model.n_layers-1, len(model.act_mb_per_layer)-1)
    comm_latency = S_prefill*transmission_latency_ms(net, devs[i].name, devs[j].name, model.act_mb_per_layer[last_layer_idx])
    latency_ms = sum_hi + (N - 1) * max_hi + comm_latency
    
    if h_list:
        stage_starts = [[0.0]*len(h_list) for _ in range(N)]
        stage_ends   = [[0.0]*len(h_list) for _ in range(N)]
        for i_stage in range(N):
            for j_token in range(len(h_list)):
                if i_stage == 0 and j_token == 0:
                    stage_starts[i_stage][j_token] = 0.0
                elif i_stage == 0:
                    stage_starts[i_stage][j_token] = stage_ends[i_stage][j_token-1]
                elif j_token == 0:
                    stage_starts[i_stage][j_token] = stage_ends[i_stage-1][j_token]
                else:
                    stage_starts[i_stage][j_token] = max(stage_ends[i_stage-1][j_token], stage_ends[i_stage][j_token-1])
                stage_ends[i_stage][j_token] = stage_starts[i_stage][j_token] + h_list[j_token]

        t_stage1_done_last = stage_ends[0][-1]
        t_laststage_done_last = stage_ends[-1][-1]
        T_overlap =max(0.0, t_laststage_done_last - t_stage1_done_last)
    else:
        stage_ends = [[]]
        T_overlap = 0.0
        t_stage1_done_last = 0.0
        t_laststage_done_last = 0.0
        
    details = {
        "token_parts": parts_tokens,
        "sum_hi_ms": sum_hi,
        "max_hi_ms": max_hi,
        "timeline_stage_ends": stage_ends,
        "t_stage1_done_last": t_stage1_done_last,
        "t_laststage_done_last": t_laststage_done_last,
        "T_overlap_ms": T_overlap
    }
    return latency_ms, details
def cloud_assisted_prefill_latency_ms(model,devs,S_prefill:int,net):
    R=cloud_assisted_llm_partition(model, devs, net)
    if not R:  # return a safe default for empty partitions
        return 0.0, {"error": "No valid partition found"}
    
    _,_,j=R[0]
    _,_,i=R[-1]
    N=len(R)
    max_subseq = MAX_SUBSEQ_PER_DEVICE_FACTOR * N
    parts_tokens, max_hi = adaptive_sequence_partition_cloud_assisted(S_prefill, max_subseq, MIN_SUBSEQ_LEN,devs,model,net)
    h_list, yprev = [], 0
    for seg in parts_tokens:
        h_list.append(stage_latency_ms(seg, yprev,devs,model,net))
        yprev += seg
    sum_hi = sum(h_list)
    
    last_layer_idx = min(model.n_layers-1, len(model.act_mb_per_layer)-1)
    comm_latency = S_prefill*transmission_latency_ms(net, devs[i].name, devs[j].name, model.act_mb_per_layer[last_layer_idx])
    latency_ms = sum_hi + (N - 1) * max_hi + comm_latency
    
    if h_list:
        stage_starts = [[0.0]*len(h_list) for _ in range(N)]
        stage_ends   = [[0.0]*len(h_list) for _ in range(N)]
        for i_stage in range(N):
            for j_token in range(len(h_list)):
                if i_stage == 0 and j_token == 0:
                    stage_starts[i_stage][j_token] = 0.0
                elif i_stage == 0:
                    stage_starts[i_stage][j_token] = stage_ends[i_stage][j_token-1]
                elif j_token == 0:
                    stage_starts[i_stage][j_token] = stage_ends[i_stage-1][j_token]
                else:
                    stage_starts[i_stage][j_token] = max(stage_ends[i_stage-1][j_token], stage_ends[i_stage][j_token-1])
                stage_ends[i_stage][j_token] = stage_starts[i_stage][j_token] + h_list[j_token]

        t_stage1_done_last = stage_ends[0][-1]
        t_laststage_done_last = stage_ends[-1][-1]
        T_overlap =max(0.0, t_laststage_done_last - t_stage1_done_last)
    else:
        stage_ends = [[]]
        T_overlap = 0.0
        t_stage1_done_last = 0.0
        t_laststage_done_last = 0.0
        
    details = {
        "token_parts": parts_tokens,
        "sum_hi_ms": sum_hi,
        "max_hi_ms": max_hi,
        "timeline_stage_ends": stage_ends,
        "t_stage1_done_last": t_stage1_done_last,
        "t_laststage_done_last": t_laststage_done_last,
        "T_overlap_ms": T_overlap
    }
    return latency_ms, details

def predictive_decoding_gain(
    prefill_details,
    p_hit: float,
    rollback_overhead_ms: float,
    cleanup_ms: Union[float, Tuple[float,float], Callable[[],float]] = 0.2
):
    T_overlap = float(prefill_details.get("T_overlap_ms", 0.0))
    prep_time = T_overlap * (0.9 + 0.2 * random.random())

    if isinstance(cleanup_ms, tuple) and len(cleanup_ms) == 2:
        cleanup_val = random.uniform(cleanup_ms[0], cleanup_ms[1])
    elif callable(cleanup_ms):
        cleanup_val = cleanup_ms()
    else:
        cleanup_val = float(cleanup_ms)

    rand = random.random()
    if rand < p_hit:
        saved = prep_time
        overhead = 0.0
        result = saved
    else:
        overhead =rollback_overhead_ms + cleanup_val
        saved = 0.0
        result = -overhead

    info = {
        "rand": round(rand,3),
        "prep_time_ms": round(prep_time,2),
        "cleanup_val_ms": round(cleanup_val,2),
        "saved_ms": round(saved,2),
        "overhead_ms": round(overhead,2),
        "p_hit": p_hit,
    }
    return result, info
def edge_shard_baseline(model, devs, net,S_prefill:int):
    R=optimal_llm_partition(model, devs, net)
    shards=[]
    place=[]
    for(s,e,j) in R:
        shards.append((s,e))
        place.append(j)
    ms = sequential_inference_latency_ms(model, devs, net, shards, place, src_idx=place[0])
    return ms*S_prefill,"OK"
def cloud_assisted_edge_shard_baseline(model, devs, net,S_prefill:int):
    R=cloud_assisted_llm_partition(model, devs, net)
    shards=[]
    place=[]
    for(s,e,j) in R:
        shards.append((s,e))
        place.append(j)
    ms = sequential_inference_latency_ms(model, devs, net, shards, place, src_idx=place[0])
    return ms*S_prefill,"OK"
def main():
    devs = build_uav_swarm_devices()
    net  = build_fanet_network(devs)
    models = [build_llama_profile("Llama2-13B")]
    rows = []

    for m in models:
        try:
            R = optimal_llm_partition(m, devs, net)

            for (s,e,j) in R:
             q, info = build_stage_latency_model(
             devs[j],
             e-s+1,
             m,
             calibrate=False
             )

            print(f"\n===== {devs[j].name} =====")
            print(f"layers: [{s}, {e}]")
            print(f"a = {info['a']:.6f}")
            print(f"b = {info['b']:.6f}")
            print(f"c = {info['c']:.6f}")
            print(f"d = {info['d']:.6f}")
            solo = edge_solo_baseline(m, devs, net, S_prefill=64)
            ce_even = cloud_uav_even_baseline(m, devs, net, S_prefill=64)
            ce_opt = cloud_uav_optimal_cut_baseline(m, devs, net, S_prefill=64)
            cleanup_draw = lambda: max(0, random.gauss(560, 80)) 
            lat, details = orion_prefill_latency_ms(m, devs, S_prefill=64, net=net)
            lat_cloud, details_cloud = cloud_assisted_prefill_latency_ms(m, devs, S_prefill=64, net=net)
            pred_result, _ = predictive_decoding_gain(details, p_hit=1, rollback_overhead_ms=1.0, cleanup_ms=cleanup_draw)
            mine_val = lat - pred_result
            cloud_edge_shard_latency = cloud_assisted_edge_shard_baseline(m, devs, net, S_prefill=64)
            rows.append((m.name, "Edge-Solo", solo[0], solo[1]))
            rows.append((m.name, "Cloud-Edge-Even", ce_even[0], ce_even[1]))
            rows.append((m.name, "Cloud-Edge-Opt", ce_opt[0], ce_opt[1]))
            rows.append((m.name, "Orion", mine_val, "OK"))
            rows.append((m.name, "EdgeShard", cloud_edge_shard_latency[0], cloud_edge_shard_latency[1]))
            rows.append((m.name, "Jupiter", lat_cloud, "OK"))
        except Exception as e:
            print(f"Error while processing model {m.name}: {e}")
            rows.append((m.name, "Edge-Solo", None, "ERROR"))
            rows.append((m.name, "Cloud-Edge-Even", None, "ERROR"))
            rows.append((m.name, "Cloud-Edge-Opt", None, "ERROR"))
            rows.append((m.name, "Ours", None, "ERROR"))

    df = pd.DataFrame(rows, columns=["Model", "Method", "Latency_ms", "Status"])
    print(df)
    df.to_csv("orion_latency_results.csv", index=False)

if __name__ == "__main__":
    main()
