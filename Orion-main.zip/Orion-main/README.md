# Orion Simulation Framework

This repository contains a Python simulation framework for evaluating Orion, an edge-only collaborative inference framework for large language model prefill acceleration in heterogeneous UAV swarm environments.

## Repository Layout

- `orion_simulator.py`: Core Orion simulator, UAV/FANET models, optimal LLM partitioning, adaptive sequence partitioning, predictive decoding model, and baseline latency evaluation.
- `predictive_break_even.py`: Break-even experiment for predictive decoding accuracy. It writes `breakeven_results.csv` and `breakeven_plot.png`.
- `partition_robustness.py`: Monte Carlo robustness experiment for static DP layer partitioning under compute and communication noise. It writes CSV summaries and `robustness_plot.png`.
- `prediction_head_profile.py`: Optional profiling script for training a lightweight Linear or MLP prediction head on real text prompts.
- `prompt.txt`: Example prompt file for `prediction_head_profile.py`.

## Requirements

The scripts use Python 3 with the following packages:

```bash
pip install numpy pandas matplotlib torch transformers
```

`torch` and `transformers` are only required for `prediction_head_profile.py`. The simulation-only experiments use `numpy`, `pandas`, and `matplotlib`.

## Running the Experiments

Run the core simulator:

```bash
python3 orion_simulator.py
```

Run the predictive decoding break-even experiment:

```bash
python3 predictive_break_even.py
```

Run the robustness experiment:

```bash
python3 partition_robustness.py
```

Profile a real prediction head:

```bash
python3 prediction_head_profile.py   --model TinyLlama/TinyLlama-1.1B-Chat-v1.0   --texts prompt.txt   --use_mlp   --epochs 50   --max_samples 200   --out profile.json
```

The `--texts` file must contain one prompt per line. At least 10 valid lines are required.

## Notes

The simulator is intended for algorithm-level evaluation of partitioning, pipeline behavior, and predictive decoding trade-offs. Absolute latency values should be calibrated with hardware profiling before being used as deployment claims.

Random seeds are fixed in the scripts to make the generated results reproducible under the same software environment.
