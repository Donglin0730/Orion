"""
Robustness experiment using Monte Carlo noise injection.

This script evaluates how a static DP layer partition behaves under
compute and communication noise.
"""

import random
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from copy import deepcopy
from typing import List, Tuple

from orion_simulator import (
    build_uav_swarm_devices, build_fanet_network, build_llama_profile,
    EdgeDevice, EdgeNetwork, LLMProfile,
    transmission_latency_ms,
    build_stage_latency_model,
    optimal_llm_partition,
    adaptive_sequence_partition,
    MAX_SUBSEQ_PER_DEVICE_FACTOR, MIN_SUBSEQ_LEN,
)

# Reproducibility.
random.seed(42)
np.random.seed(42)

N_TRIALS      = 100          # Monte Carlo trials
S_PREFILL     = 64           # prefill tokens
MODEL_NAME    = "Llama2-13B"

SIGMA_COMP_NOMINAL = 0.10    # compute noise std ratio
SIGMA_COMM_NOMINAL = 0.20    # communication noise std ratio
SIGMA_EXTREME      = 0.30    # extreme-case noise ratio


def perturb_llm_profile(model: LLMProfile,
                  sigma_comp: float,
                  rng: np.random.Generator) -> LLMProfile:
    """Apply multiplicative Gaussian noise to per-layer compute time."""
    noisy_comps = [
        max(1e-3, c * (1.0 + rng.normal(0, sigma_comp)))
        for c in model.base_compute_ms_per_layer
    ]
    return LLMProfile(
        name=model.name,
        n_layers=model.n_layers,
        mem_gb_required=model.mem_gb_required,
        act_mb_per_layer=list(model.act_mb_per_layer),
        base_compute_ms_per_layer=noisy_comps,
        mem_gb_required_per_layer=list(model.mem_gb_required_per_layer),
    )

def perturb_edge_network(net: EdgeNetwork,
                sigma_comm: float,
                rng: np.random.Generator) -> EdgeNetwork:
    """Apply multiplicative Gaussian noise to link bandwidths."""
    noisy_bw = {
        k: max(v * 0.4, v * (1.0 + rng.normal(0, sigma_comm)))
        for k, v in net.bw_mbps.items()
    }
    return EdgeNetwork(bw_mbps=noisy_bw)


def evaluate_static_partition_latency(model: LLMProfile,
                           devs: List[EdgeDevice],
                           net: EdgeNetwork,
                           R_partition: List[Tuple[int,int,int]]) -> float:
    """
    Evaluate latency for a fixed layer partition under the supplied
    model and network parameters.
    """
    from orion_simulator import build_stage_latency_model, adaptive_sequence_partition

    if not R_partition:
        return float("inf")

    N = len(R_partition)
    _, _, j_first = R_partition[0]
    _, _, i_last  = R_partition[-1]

    q_fns = []
    for (s, e, j) in R_partition:
        q_fn, _ = build_stage_latency_model(devs[j], e - s + 1, model, calibrate=False)
        q_fns.append(q_fn)

    
    max_subseq = MAX_SUBSEQ_PER_DEVICE_FACTOR * N

    # Temporarily fix the partition used inside adaptive_sequence_partition.
    
    
    import orion_simulator as _exp3
    _orig_jdp = _exp3.optimal_llm_partition

    def _patched_jdp(model_, devs_, net_):
        return R_partition

    _exp3.optimal_llm_partition = _patched_jdp
    try:
        parts_tokens, _ = adaptive_sequence_partition(
            S_PREFILL, max_subseq, MIN_SUBSEQ_LEN, devs, model, net
        )
        h_list, yprev = [], 0
        for seg in parts_tokens:
            h_list.append(q_fns[0](seg, yprev))
            yprev += seg
    finally:
        # Always restore the original solver.
        _exp3.optimal_llm_partition = _orig_jdp

    if not h_list:
        return float("inf")

    sum_hi = sum(h_list)
    max_hi = max(h_list)

    last_layer_idx = min(model.n_layers - 1, len(model.act_mb_per_layer) - 1)
    comm_lat = S_PREFILL * transmission_latency_ms(
        net, devs[i_last].name, devs[j_first].name,
        model.act_mb_per_layer[last_layer_idx]
    )
    return sum_hi + (N - 1) * max_hi + comm_lat




def build_clean_partition_baseline():
    """Run DP once in the clean environment."""
    random.seed(42); np.random.seed(42)
    devs  = build_uav_swarm_devices()
    net   = build_fanet_network(devs)
    model = build_llama_profile(MODEL_NAME)

    R_static = optimal_llm_partition(model, devs, net)

    from orion_simulator import orion_prefill_latency_ms
    L_clean, details = orion_prefill_latency_ms(model, devs, S_PREFILL, net)

    print("=" * 60)
    print(f"  Clean baseline latency  : {L_clean:,.2f} ms")
    print(f"  DP partition segments        : {len(R_static)}")
    for seg in R_static:
        print(f"    layers [{seg[0]:>2d}..{seg[1]:>2d}] -> dev#{seg[2]}")
    print("=" * 60)
    return devs, net, model, R_static, L_clean


def run_noise_injection_trials(devs, net, model, R_static, L_clean,
                    sigma_comp: float, sigma_comm: float,
                    n_trials: int = N_TRIALS,
                    seed_offset: int = 0,
                    label: str = ""):
    """
    For each trial, evaluate the static partition and compare it with
    a freshly optimized DP partition under the same perturbation.
    """
    import time
    records = []
    rng = np.random.default_rng(1234 + seed_offset)
    t_start = time.time()

    for trial in range(n_trials):
        t_trial = time.time()

        model_n = perturb_llm_profile(model, sigma_comp, rng)
        net_n   = perturb_edge_network(net,   sigma_comm, rng)

        L_static = evaluate_static_partition_latency(model_n, devs, net_n, R_static)

        R_opt = optimal_llm_partition(model_n, devs, net_n)
        L_opt = evaluate_static_partition_latency(model_n, devs, net_n, R_opt)

        
        partition_equal = (len(R_static) == len(R_opt) and
                           all(a == b for a, b in zip(R_static, R_opt)))
        
        latency_equal = abs(L_static - L_opt) < 1e-6
        match = partition_equal or latency_equal

        deg = (L_static - L_opt) / max(L_opt, 1e-6)

        records.append({
            "trial":           trial,
            "L_static_ms":     L_static,
            "L_opt_ms":        L_opt,
            "partition_match": int(match),
            "degradation":     deg,
        })

        elapsed = time.time() - t_trial
        print(f"  [{label}] trial {trial+1:>3d}/{n_trials} | "
              f"L_static={L_static:>10,.1f}ms | "
              f"L_opt={L_opt:>10,.1f}ms | "
              f"match={'✓' if match else '✗'} | "
              f"deg={deg*100:+6.1f}% | "
              f"{elapsed:.1f}s")

        if (trial + 1) % 10 == 0:
            so_far = pd.DataFrame(records)
            cv_now    = so_far["L_static_ms"].std() / so_far["L_static_ms"].mean()
            hit_now   = so_far["partition_match"].mean() * 100
            deg_now   = so_far["degradation"].mean() * 100
            elapsed_total = time.time() - t_start
            remaining = elapsed_total / (trial + 1) * (n_trials - trial - 1)
            print(f"  {'─'*65}")
            print(f"  ▶ completed {trial+1:>3d}/{n_trials} | "
                  f"CV={cv_now:.3f} | match rate={hit_now:.1f}% | "
                  f"average degradation={deg_now:.1f}% | "
                  f"elapsed={elapsed_total:.0f}s remaining={remaining:.0f}s")
            print(f"  {'─'*65}")

    return pd.DataFrame(records)


def summarize_noise_trials(df: pd.DataFrame, label: str):
    mu  = df["L_static_ms"].mean()
    sig = df["L_static_ms"].std()
    cv  = sig / mu
    match_rate = df["partition_match"].mean()
    deg_mean   = df["degradation"].mean()

    print(f"\n{'─'*55}")
    print(f"  Scenario：{label}")
    print(f"{'─'*55}")
    print(f"  L_static mean     : {mu:,.2f} ms")
    print(f"  L_static std   : {sig:,.2f} ms")
    print(f"  CV       : {cv:.4f}")
    print(f"  Partition match rate        : {match_rate*100:.1f}%")
    print(f"  Average degradation      : {deg_mean*100:.1f}%")
    return {"label": label, "mu": mu, "sigma": sig, "cv": cv,
            "match_rate": match_rate, "deg_mean": deg_mean}


def plot_results(df_nominal: pd.DataFrame,
                 df_extreme: pd.DataFrame,
                 stats_nominal: dict,
                 stats_extreme: dict,
                 L_clean: float,
                 save_path: str = "robustness_plot.png"):

    fig = plt.figure(figsize=(14, 7), dpi=150)
    fig.patch.set_facecolor("white")
    gs = gridspec.GridSpec(2, 3, figure=fig,
                           hspace=0.55, wspace=0.38,
                           top=0.88, bottom=0.08)

    C_NOM  = "#185FA5"
    C_EXT  = "#D85A30"
    C_CLEAN= "#73726C"

    ax1 = fig.add_subplot(gs[0, 0])
    ax1.hist(df_nominal["L_static_ms"], bins=30, color=C_NOM,
             alpha=0.75, edgecolor="white", linewidth=0.4)
    ax1.axvline(L_clean, color=C_CLEAN, lw=1.5, ls="--",
                label=f"Clean: {L_clean/1000:.2f}s")
    ax1.axvline(df_nominal["L_static_ms"].mean(), color=C_NOM, lw=1.5, ls="-",
                label=f"Mean: {stats_nominal['mu']/1000:.2f}s")
    ax1.set_title("(a) Latency Distribution\n(σ_comp=10%, σ_comm=20%)", fontsize=9)
    ax1.set_xlabel("Latency (ms)", fontsize=8)
    ax1.set_ylabel("Count", fontsize=8)
    ax1.legend(fontsize=7.5)
    ax1.spines[["top", "right"]].set_visible(False)
    ax1.text(0.97, 0.92, f"CV={stats_nominal['cv']:.3f}",
             transform=ax1.transAxes, ha="right", fontsize=8.5,
             color=C_NOM, fontweight="bold")
    ax1.text(0.97, 0.82, f"Avg deg={stats_nominal['deg_mean']*100:.1f}%",
             transform=ax1.transAxes, ha="right", fontsize=8.5,
             color=C_EXT, fontweight="bold")

    ax2 = fig.add_subplot(gs[0, 1])
    x = df_nominal["trial"].values
    ax2.plot(x, df_nominal["L_static_ms"].values / 1000,
             color=C_NOM, lw=0.8, alpha=0.7, label="L_static")
    ax2.plot(x, df_nominal["L_opt_ms"].values / 1000,
             color=C_EXT, lw=0.8, alpha=0.5, ls="--", label="L_opt (reDP)")
    ax2.axhline(L_clean / 1000, color=C_CLEAN, lw=1.2, ls=":",
                label="Clean baseline")
    ax2.set_title("(b) Per-Trial Latency\n(Nominal Noise)", fontsize=9)
    ax2.set_xlabel("Trial index", fontsize=8)
    ax2.set_ylabel("Latency (s)", fontsize=8)
    ax2.legend(fontsize=7)
    ax2.spines[["top", "right"]].set_visible(False)

    ax3 = fig.add_subplot(gs[0, 2])
    hit  = stats_nominal["match_rate"]
    miss = 1.0 - hit
    wedge_colors = [C_NOM, "#cccccc"]
    ax3.pie([hit, miss],
            labels=[f"Match\n{hit*100:.1f}%", f"Re-opt\n{miss*100:.1f}%"],
            colors=wedge_colors,
            startangle=90,
            wedgeprops={"edgecolor": "white", "linewidth": 1.5},
            textprops={"fontsize": 9})
    ax3.set_title("(c) Partition Match Rate)", fontsize=9)

    ax4 = fig.add_subplot(gs[1, 0])
    deg_pct = df_extreme["degradation"].values * 100
    ax4.hist(deg_pct, bins=30, color=C_EXT,
             alpha=0.75, edgecolor="white", linewidth=0.4)
    ax4.axvline(deg_pct.mean(), color=C_EXT, lw=1.5, ls="-",
                label=f"Mean={deg_pct.mean():.1f}%")

    ax4.set_title("(d) Degradation Distribution\n(Extreme Noise σ=30%)", fontsize=9)
    ax4.set_xlabel("(L_static − L_opt) / L_opt  (%)", fontsize=8)
    ax4.set_ylabel("Count", fontsize=8)
    ax4.legend(fontsize=7.5)
    ax4.spines[["top", "right"]].set_visible(False)
    ax4.text(0.97, 0.92, f"Mean={deg_pct.mean():.1f}%",
             transform=ax4.transAxes, ha="right", fontsize=8.5,
             color=C_EXT, fontweight="bold")

    ax5 = fig.add_subplot(gs[1, 1])
    categories = ["CV", "Match Rate"]
    nominal_vals = [stats_nominal["cv"], stats_nominal["match_rate"]]
    extreme_vals = [stats_extreme["cv"], stats_extreme["match_rate"]]
    targets      = [0.12, 0.84]
    x_pos = np.arange(len(categories))
    w = 0.25
    bars_n = ax5.bar(x_pos - w, nominal_vals, w, color=C_NOM,
                     alpha=0.85, label="Nominal (σ=10/20%)")
    bars_e = ax5.bar(x_pos,     extreme_vals, w, color=C_EXT,
                     alpha=0.85, label="Extreme (σ=30%)")

    for b in list(bars_n) + list(bars_e):
        ax5.text(b.get_x() + b.get_width()/2, b.get_height() + 0.005,
                 f"{b.get_height():.3f}", ha="center", fontsize=7)
    ax5.set_xticks(x_pos)
    ax5.set_xticklabels(categories, fontsize=8)
    ax5.set_ylim(0, 1.05)
    ax5.set_title("(e) Summary Metrics", fontsize=9)
    ax5.legend(fontsize=7, loc="upper right", labels=["Nominal (σ=10/20%)", "Extreme (σ=30%)"])
    ax5.spines[["top", "right"]].set_visible(False)

    ax6 = fig.add_subplot(gs[1, 2])
    for df_, color, lbl in [
        (df_nominal, C_NOM, "Nominal"),
        (df_extreme, C_EXT, "Extreme"),
    ]:
        vals = np.sort(df_["L_static_ms"].values / 1000)
        cdf  = np.arange(1, len(vals)+1) / len(vals)
        ax6.plot(vals, cdf, color=color, lw=1.8, label=lbl)
    ax6.axvline(L_clean / 1000, color=C_CLEAN, lw=1.2, ls="--",
                label="Clean baseline")
    ax6.set_title("(f) CDF of End-to-End Latency", fontsize=9)
    ax6.set_xlabel("Latency (s)", fontsize=8)
    ax6.set_ylabel("CDF", fontsize=8)
    ax6.legend(fontsize=7.5)
    ax6.spines[["top", "right"]].set_visible(False)
    ax6.grid(axis="both", ls="--", lw=0.4, alpha=0.4)
    _all_vals = np.concatenate([
        df_nominal["L_static_ms"].values,
        df_extreme["L_static_ms"].values,
    ])
    _finite = _all_vals[np.isfinite(_all_vals)]
    _p2  = np.percentile(_finite, 2)  / 1000
    _p98 = np.percentile(_finite, 98) / 1000
    ax6.set_xlim(_p2 * 0.95, _p98 * 1.05)

    fig.suptitle(
        f"Robustness Analysis — {MODEL_NAME}, S={S_PREFILL} tokens\n"
        f"Monte Carlo N={N_TRIALS} trials",
        fontsize=11, y=1.01
    )

    plt.savefig(save_path, dpi=200, bbox_inches="tight",
                facecolor="white")
    print(f"\nPlot saved：{save_path}")
    return fig


def main():
    devs, net, model, R_static, L_clean = build_clean_partition_baseline()

    print(f"\n[nominal noise] running {N_TRIALS} Monte Carlo trials...")
    df_nominal = run_noise_injection_trials(
        devs, net, model, R_static, L_clean,
        sigma_comp=SIGMA_COMP_NOMINAL,
        sigma_comm=SIGMA_COMM_NOMINAL,
        n_trials=N_TRIALS,
        seed_offset=0,
        label="nominal noise",
    )
    stats_nom = summarize_noise_trials(df_nominal, "Nominal (σ_comp=10%, σ_comm=20%)")

    print(f"\n[extreme noise] running {N_TRIALS} Monte Carlo trials...")
    df_extreme = run_noise_injection_trials(
        devs, net, model, R_static, L_clean,
        sigma_comp=SIGMA_EXTREME,
        sigma_comm=SIGMA_EXTREME,
        n_trials=N_TRIALS,
        seed_offset=999,
        label="extreme noise",
    )
    stats_ext = summarize_noise_trials(df_extreme, "Extreme (σ=30%)")

    df_nominal.to_csv("robustness_nominal.csv", index=False)
    df_extreme.to_csv("robustness_extreme.csv", index=False)
    print("\nCSV saved：robustness_nominal.csv / robustness_extreme.csv")

    plot_results(df_nominal, df_extreme, stats_nom, stats_ext,
                 L_clean, save_path="robustness_plot.png")

    print("\n" + "=" * 60)
    print("  Key summary")
    print("=" * 60)
    print(f"  CV              = {stats_nom['cv']:.4f}")
    print(f"  match rate          = {stats_nom['match_rate']*100:.1f}%")
    print(f"  Extreme degradation mean    = {stats_ext['deg_mean']*100:.1f}%")
    print("=" * 60)


if __name__ == "__main__":
    main()
