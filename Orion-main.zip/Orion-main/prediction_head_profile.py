"""
prediction_head_profile.py
Profile a lightweight prediction head for Orion's predictive decoding path.

Example:
python prediction_head_profile.py \
  --model TinyLlama/TinyLlama-1.1B-Chat-v1.0 \
  --texts prompt.txt \
  --use_mlp \
  --epochs 50 \
  --max_samples 200 \
  --out profile.json
"""
import os
import time
import json
import argparse
from typing import List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForCausalLM

  

  
class LinearPredictionHead(nn.Module):
    def __init__(self, hidden_size: int, vocab_size: int):
        super().__init__()
        self.out = nn.Linear(hidden_size, vocab_size, bias=False)
    def forward(self, h_last):
        return self.out(h_last)

class MLPPredictionHead(nn.Module):
    def __init__(self, hidden_size: int, vocab_size: int, width: int = 4):
        super().__init__()
        mid = max(128, hidden_size // width)
        self.net = nn.Sequential(
            nn.Linear(hidden_size, mid),
            nn.GELU(),
            nn.Linear(mid, vocab_size)
        )
    def forward(self, h_last):
        return self.net(h_last)

def read_texts(path: str, max_samples: int = None) -> List[str]:
    texts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line: 
                continue
            texts.append(line)
            if max_samples and len(texts) >= max_samples:
                break
    return texts

def build_next_token_pairs(tokenizer: AutoTokenizer, texts: List[str], max_len: int = 512) -> List[Tuple[torch.Tensor, int]]:
    """Encode each line as (context_tokens, next_token_label)."""
    pairs = []
    for t in texts:
        ids = tokenizer.encode(t, add_special_tokens=False)
        if len(ids) < 2:
            continue
        if len(ids) > max_len:
            ids = ids[:max_len]
        x = torch.tensor(ids[:-1], dtype=torch.long)
        y = ids[-1]
        pairs.append((x, y))
    return pairs

def collate(batch, pad_id: int):
    maxlen = max(len(x[0]) for x in batch)
    xs, ys, attn = [], [], []
    for x, y in batch:
        pad = [pad_id] * (maxlen - len(x))
        xs.append(torch.tensor(list(x) + pad, dtype=torch.long))
        ys.append(torch.tensor(y, dtype=torch.long))
        attn.append(torch.tensor([1]*len(x) + [0]*len(pad), dtype=torch.long))
    return torch.stack(xs), torch.stack(ys), torch.stack(attn)

@torch.no_grad()
def evaluate_prediction_head(model, head, dl, device):
    correct = 0
    total = 0
    ce_sum = 0.0
    for xb, yb, attn in dl:
        xb, yb, attn = xb.to(device), yb.to(device), attn.to(device)
        out = model(xb, attention_mask=attn, output_hidden_states=True)
        h_last = out.hidden_states[-1][:, -1, :]
        logits = head(h_last)
        pred = torch.argmax(logits, dim=-1)
        correct += (pred == yb).sum().item()
        total += yb.numel()
        ce_sum += F.cross_entropy(logits, yb, reduction="sum").item()
    acc = correct / max(1,total)
    nll = ce_sum / max(1,total)
    return acc, nll

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default="TinyLlama/TinyLlama-1.1B-Chat-v1.0")
    ap.add_argument("--tokenizer", type=str, default=None)
    ap.add_argument("--texts", type=str, required=True, help="Text file with one prompt per line")
    ap.add_argument("--out", type=str, default="profile.json")
    ap.add_argument("--use_mlp", action="store_true", help="Use MLPPredictionHead instead of the default LinearPredictionHead")
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=5e-4)
    ap.add_argument("--max_len", type=int, default=512)
    ap.add_argument("--max_samples", type=int, default=1000)
    ap.add_argument("--val_ratio", type=float, default=0.2)
    ap.add_argument("--stage_split", type=int, default=-1,help="Stage-1 layer index; -1 uses the final hidden state")
    args = ap.parse_args()

    tok_name = args.tokenizer or args.model
    tokenizer = AutoTokenizer.from_pretrained(tok_name, use_fast=True)
    pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id

    print("Loading model:", args.model)
    model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32)
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    texts = read_texts(args.texts, args.max_samples)
    pairs = build_next_token_pairs(tokenizer, texts, max_len=args.max_len)
    if len(pairs) < 10:
        raise RuntimeError("Too few samples. Provide at least 10 valid text lines.")

    split = int(len(pairs) * (1 - args.val_ratio))
    train_pairs, val_pairs = pairs[:split], pairs[split:]

    from torch.utils.data import DataLoader
    train_dl = DataLoader(train_pairs, batch_size=args.batch_size, shuffle=True, collate_fn=lambda b: collate(b, pad_id))
    val_dl   = DataLoader(val_pairs,   batch_size=args.batch_size, shuffle=False, collate_fn=lambda b: collate(b, pad_id))

    hidden_size = model.config.hidden_size
    vocab_size  = model.config.vocab_size
    head = (MLPPredictionHead if args.use_mlp else LinearPredictionHead)(hidden_size, vocab_size).to(device)

    opt = torch.optim.AdamW(head.parameters(), lr=args.lr)

    for ep in range(args.epochs):
        head.train()
        total_loss = 0.0
        steps = 0
        for xb, yb, attn in train_dl:
            xb, yb, attn = xb.to(device), yb.to(device), attn.to(device)
            with torch.no_grad():
                out = model(xb, attention_mask=attn, output_hidden_states=True)
                hs = out.hidden_states
                if args.stage_split == -1:
                    h_last = hs[-1][:, -1, :]
                else:
                # hidden_states[0] is the embedding output; hidden_states[k] is after layer k.
                    assert 0 < args.stage_split < len(hs), \
                       f"stage_split={args.stage_split} is out of range (hidden_states length={len(hs)})"
                    h_last = hs[args.stage_split][:, -1, :]
            logits = head(h_last)
            loss = F.cross_entropy(logits, yb)
            opt.zero_grad()
            loss.backward()
            opt.step()
            total_loss += loss.item()
            steps += 1
        acc, nll = evaluate_prediction_head(model, head, val_dl, device)
        print(f"Epoch {ep+1}: train_ce={total_loss/max(1,steps):.4f}  val_acc={acc:.3f}  val_nll={nll:.3f}")

    prompt_ids = pairs[0][0].unsqueeze(0).to(device)
    attn = torch.ones_like(prompt_ids).to(device)
    gen_steps = 8
    with torch.no_grad():
        _ = model(prompt_ids, attention_mask=attn)
    torch.cuda.synchronize() if device.type=="cuda" else None
    t0 = time.time()
    with torch.no_grad():
        x = prompt_ids
        a = attn
        for _ in range(gen_steps):
            out = model(x, attention_mask=a)
            next_id = out.logits[:, -1, :].argmax(dim=-1, keepdim=True)
            x = torch.cat([x, next_id], dim=1)
            a = torch.ones_like(x)
    torch.cuda.synchronize() if device.type=="cuda" else None
    t1 = time.time()
    per_step_ms = (t1 - t0) * 1000.0 / gen_steps
    print(f"Estimated per-step decode time: {per_step_ms:.2f} ms")

    acc, _ = evaluate_prediction_head(model, head, val_dl, device)
    profile = {
        "p_correct": float(acc),
        "per_step_ms": float(per_step_ms),
        # Measure this in the real pipeline when available.
        "stage1_share_default": None
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    print("Saved profile to", args.out)

if __name__ == "__main__":
    main()
