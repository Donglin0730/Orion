"""
Break-even experiment for Orion predictive decoding.

Usage:
  python predictive_break_even.py

Outputs:
  - Console summary of micro parameters and P_break_even
  - breakeven_results.csv
  - breakeven_plot.png
"""

import random
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D

from orion_simulator import (
    build_uav_swarm_devices, build_fanet_network, build_llama_profile,
    orion_prefill_latency_ms, predictive_decoding_gain, edge_shard_baseline,
)

# Reproducibility.
random.seed(50)
np.random.seed(50)

S_PREFILL       = 64        # prefill tokens
T_PREDICT_MS    = 35.0      # prediction head latency in ms
T_ROLLBACK_MS   = 430.0     # rollback overhead in ms
CLEANUP_MS      = 0.5       # fixed cleanup overhead in ms
N_TRIALS        = 300       # Monte Carlo trials

ACC_GRID = [0.0, 0.10, 0.175, 0.30, 0.50, 0.70, 0.85, 1.0]

MODEL_NAME = "Llama2-13B"


def extract_break_even_parameters():
    """
    Extract T_bubble, pipeline latency, and the no-prediction baseline,
    then derive P_break_even.
    """
    random.seed(50); np.random.seed(50)
    devs  = build_uav_swarm_devices()
    net   = build_fanet_network(devs)
    model = build_llama_profile(MODEL_NAME)

    lat_pipe, details = orion_prefill_latency_ms(model, devs, S_PREFILL, net)
    T_bubble = details["T_overlap_ms"]

    lat_nopre, _ = orion_prefill_latency_ms(model, devs, S_PREFILL, net)

    # Break-even condition.
    # E[ΔT] = P*T_bubble - T_predict - (1-P)*T_rollback = 0
    # => P* = (T_predict + T_rollback) / (T_bubble + T_rollback)
    P_be = (T_PREDICT_MS + T_ROLLBACK_MS) / (T_bubble + T_ROLLBACK_MS)

    print("=" * 60)
    print(f"  Model               : {MODEL_NAME}")
    print(f"  S_prefill          : {S_PREFILL} tokens")
    print("-" * 60)
    print(f"  Pipeline latency        : {lat_pipe:,.2f} ms")
    print(f"  T_bubble           : {T_bubble:,.2f} ms   <- available bubble time")
    print(f"  T_predict          : {T_PREDICT_MS:.2f} ms   <- prediction head latency")
    print(f"  T_rollback         : {T_ROLLBACK_MS:.2f} ms   <- rollback cost")
    print(f"  Orion-no-pre baseline  : {lat_nopre:,.2f} ms")
    print("-" * 60)
    print(f"  P_break_even       : {P_be*100:.4f}%  <- low threshold")
    print("=" * 60)

    return {
        "model": MODEL_NAME,
        "lat_pipe_ms": lat_pipe,
        "T_bubble_ms": T_bubble,
        "T_predict_ms": T_PREDICT_MS,
        "T_rollback_ms": T_ROLLBACK_MS,
        "P_break_even": P_be,
        "baseline_lat_ms": lat_nopre,   # Orion-no-pre
        "details": details,
    }


def sweep_prediction_accuracy(micro: dict) -> pd.DataFrame:
    """
    Run Monte Carlo trials for each p_hit in ACC_GRID.
    End-to-end latency = lat_pipe - delta + T_predict.
    """
    lat_pipe = micro["lat_pipe_ms"]
    details  = micro["details"]

    records = []
    print(f"\n{'p_hit':>8}  {'mean_lat':>12}  {'std_lat':>10}  {'min_lat':>10}  {'max_lat':>10}")
    print("-" * 60)

    for p_hit in ACC_GRID:
        random.seed(42); np.random.seed(42)      # independent seed per grid point
        trial_lats = []
        for _ in range(N_TRIALS):
            delta, _ = predictive_decoding_gain(
                details,
                p_hit=p_hit,
                rollback_overhead_ms=T_ROLLBACK_MS,
                cleanup_ms=CLEANUP_MS,
            )
            effective_lat = lat_pipe - delta + T_PREDICT_MS
            trial_lats.append(effective_lat)

        arr = np.array(trial_lats)
        records.append({
            "p_hit":    p_hit,
            "p_hit_pct": p_hit * 100,
            "mean_lat": float(arr.mean()),
            "std_lat":  float(arr.std()),
            "min_lat":  float(arr.min()),
            "max_lat":  float(arr.max()),
            "p5_lat":   float(np.percentile(arr, 5)),
            "p95_lat":  float(np.percentile(arr, 95)),
        })
        print(f"  {p_hit*100:5.1f}%   {arr.mean():>12.2f}   {arr.std():>10.2f}"
              f"   {arr.min():>10.2f}   {arr.max():>10.2f}")

    return pd.DataFrame(records)


def plot_break_even(micro: dict, df: pd.DataFrame, save_path="breakeven_plot.png"):
    baseline = micro["lat_pipe_ms"] + T_PREDICT_MS  # expected no-prediction baseline at 0% hit rate
    P_be_pct = micro["P_break_even"] * 100

    fig, ax = plt.subplots(figsize=(8, 5), dpi=150)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    x = df["p_hit_pct"].values
    y = df["mean_lat"].values
    y_lo = df["p5_lat"].values
    y_hi = df["p95_lat"].values

    ax.fill_between(x, y_lo, y_hi, alpha=0.12, color="#185FA5", label="_nolegend_")

    ax.plot(x, y, color="#185FA5", linewidth=2.2, marker="o",
            markersize=5.5, markerfacecolor="#185FA5", markeredgecolor="white",
            markeredgewidth=1.2, label="Orion (predictive decoding)", zorder=4)

    for xi, yi in zip(x, y):
        ax.text(xi, yi-300, f"{yi/1000:.2f}s",
                ha="center", va="bottom", fontsize=7.5, color="#185FA5")

    ax.axhline(baseline, color="#73726C", linewidth=1.6, linestyle="--",
               label="Orion-no-pre (baseline)", zorder=3)

    ax.axvline(P_be_pct, color="#D85A30", linewidth=1.4, linestyle=":",
               alpha=0.7, zorder=2)
    ax.scatter([P_be_pct], [baseline], color="#D85A30", s=90, zorder=6,
               edgecolors="white", linewidths=1.5, label=f"Break-even ({P_be_pct:.2f}%)")

    ax.annotate(f"({P_be_pct:.2f}%,  {baseline/1000:.2f} s)",
                xy=(P_be_pct, baseline),
                xytext=(P_be_pct + 6, baseline + 220),
                fontsize=8.5, color="#D85A30",
                arrowprops=dict(arrowstyle="->", color="#D85A30", lw=1.1))

    ax.text(101, baseline, f"{baseline/1000:.2f} s",
            va="center", ha="left", fontsize=9, color="#73726C")

    ax.set_xlabel("Prediction accuracy (%)", fontsize=11)
    ax.set_ylabel("End-to-end latency (ms)", fontsize=11)
    ax.set_title(f"Break-even analysis — {MODEL_NAME}, S={S_PREFILL} tokens", fontsize=12)
    ax.set_xlim(-1, 110)
    ax.set_ylim(y.min() - 300, baseline + 600)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0f}%"))
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v/1000:.1f}s"))
    ax.tick_params(labelsize=9.5)
    ax.grid(axis="y", linestyle="--", linewidth=0.5, alpha=0.4, color="#999")
    ax.spines[["top", "right"]].set_visible(False)

    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels, fontsize=9, loc="upper right",
              framealpha=0.92, edgecolor="#ddd")

    plt.tight_layout()
    plt.savefig(save_path, dpi=200, bbox_inches="tight")
    print(f"\nPlot saved：{save_path}")
    return fig


def main():
    micro = extract_break_even_parameters()

    print(f"\nAccuracy sweep（{N_TRIALS} Monte Carlo trials × {len(ACC_GRID)} grid points）...")
    df = sweep_prediction_accuracy(micro)

    csv_path = "breakeven_results.csv"
    df.to_csv(csv_path, index=False)
    print(f"\nCSV saved：{csv_path}")

    plot_break_even(micro, df, save_path="breakeven_plot.png")

    P_be = micro["P_break_even"]
    print("\n" + "=" * 60)
    print("  Key summary")
    print("=" * 60)
    print(f"  T_bubble   = {micro['T_bubble_ms']:.2f} ms  (cross-device pipeline bubble)")
    print(f"  T_predict  = {T_PREDICT_MS:.2f} ms  (prediction head latency)")
    print(f"  T_rollback = {T_ROLLBACK_MS:.2f} ms  (rollback overhead)")
    print(f"")
    print(f"  P* = (T_predict + T_rollback) / (T_bubble + T_rollback)")
    print(f"     = ({T_PREDICT_MS} + {T_ROLLBACK_MS}) / ({micro['T_bubble_ms']:.2f} + {T_ROLLBACK_MS})")
    print(f"     = {P_be*100:.4f}%")
    print(f"")
    print(f"  Conclusion: prediction accuracy only needs to exceed {P_be*100:.2f}%，")
    print(f"  to keep end-to-end latency below the no-prediction baseline.")
    print("=" * 60)


if __name__ == "__main__":
    main()
